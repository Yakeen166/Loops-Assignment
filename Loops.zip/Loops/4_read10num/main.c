#include <stdio.h>

int main()
{
    int num;
    int sum = 0;
    float average = 0;

    printf("Type the number and press enter:\n");
    for(int i=1; i<=10; i++){
        scanf("%d", &num);
        sum += num;
    }

    average = sum / 10;

    printf("The sum is: %d and average is: %f\n", sum, average);

    return 0;
}
