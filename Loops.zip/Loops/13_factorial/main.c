//#include <stdio.h>

//int main()
//{
//    int num,factorial;
//    printf("Enter the number : ");
//    scanf("%d",&num);

//    for(int i=1; i<num; i++){
//        factorial = num*(num-i);
//        printf("%d",factorial);
//    }
//return 0;
//}

#include <stdio.h>

int main()
{
    int n;
    printf("enter the number:");
    scanf("%d", &n);
    double factorial = 1;

    int l = n+1;

    for(int i=n; i>=1; i--){
        factorial *= (l-1);
        l--;
    }
    printf("%e\n", factorial);
    return 0;
}
