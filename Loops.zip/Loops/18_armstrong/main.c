#include <stdio.h>
#include <math.h>

int main()
{
    int n;
    printf("Enter the nth term: ");
    scanf("%d", &n);

    int totaldigits;
    int lastdigit;
    int sum;
    int num;

    for(int i=1; i<=n; i++){
        sum = 0;
        num = i;
        totaldigits = (int) log10(num)+1; //this gives the totalno of digits in the given number

        while(num > 0){
            lastdigit = num % 10;
            sum += pow(lastdigit, totaldigits);
            num /= 10;
        }

        if(i == sum){
            printf("%d\n", i);
        }

    }
    return 0;
}
