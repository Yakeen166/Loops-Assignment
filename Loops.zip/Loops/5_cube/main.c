#include <stdio.h>
#include <math.h>

int main()
{
    int num;
    printf("Enter the nth term:");
    scanf("%d", &num);

    for(int i=1; i<=num; i++){
        int power = pow(i,3);
        printf("%d and its cube is %d\n", i, power);
    }
    return 0;
}
