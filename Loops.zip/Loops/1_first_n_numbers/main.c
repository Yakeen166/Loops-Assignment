#include <stdio.h>

int main()
{
    int i;
    printf("The First 10 natural numbers are  :\n");

    for(i=1 ; i<=10 ; i++){
      printf("%d\t",i);
    }
printf("\n");
    return 0;
}
