#include <stdio.h>

int main()
{
    int n;
    printf("Enter the nth term:");
    scanf("%d", &n);

    int i=1;
    int j=1;
    int sum = 0;

    printf("the odd natural number till %dterm are:\n",n);
    while(i < n+1){
        printf("%d\n", j);
        sum += j;
        j+=2;
        i++;
    }

    printf("their sum is: %d\n", sum);
    return 0;
}
