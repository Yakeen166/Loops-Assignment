#include <stdio.h>

int main()
{
int i,num,sum = 0 ;
printf("Enter the nth natural number:");
scanf("%d",&num);

for(i=1; i<=num; i++){
printf("%d\n",i);
sum+=i;
}
printf("Their sum is %d.\n",sum);
    return 0;
}
