#include <stdio.h>

int main()
{
    int num;
    int sum = 0;
    int remaining;
    printf("Enter the integer: ");
    scanf("%d", &num);

    while(num != 0){
        remaining = num % 10;
        sum += remaining;
        num /= 10;

    }

    printf("Sum is : %d\n",sum);


    return 0;
}
