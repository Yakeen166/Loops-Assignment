#include <stdio.h>

int main()
{
    int num,sum = 0;
    printf("Enter the nth number :");
    scanf("%d",&num);
    printf("\n");

    printf("The square natural number upto %d are:\n",num);

    for(int i=1; i<=num; i++){
        printf("%d\n",i*i);
        sum += i*i;

    }
    printf("And their sum is %d\n",sum);

    return 0;
}
